var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1711498996903.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b9f79ce8-5da9-4f98-acf8-087f714232a0" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="Thank You"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b9f79ce8-5da9-4f98-acf8-087f714232a0-1711498996903.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="357.4px" datasizeheight="201.1px" dataX="36.3" dataY="220.4" aspectRatio="0.5625"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4b8885b8-aa06-4076-9a2a-87ec317e8742.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="W-2 Form"   datasizewidth="246.6px" datasizeheight="55.0px" dataX="91.7" dataY="387.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">W-2 Form</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer pageunload ie-background commentable non-processed" customid="THANK YOU!"   datasizewidth="323.6px" datasizeheight="57.0px" dataX="53.2" dataY="466.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">THANK YOU!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;