var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1711498996903.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="Start Screen"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1711498996903.css" />\
      <div class="freeLayout">\
      <div id="s-Group_19" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_17" class="text firer focusin focusout pageunload commentable non-processed" customid="Dialog input"  datasizewidth="400.0px" datasizeheight="40.0px" dataX="15.0" dataY="457.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="First Name"/></div></div>  </div></div></div>\
        <div id="s-Subtraction_5" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="386.0" dataY="468.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="385.99995755694204 468.0000900163443 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_5-d1224" d="M392.2579399028198 473.8407529084601 C392.35813920692016 473.8407529084601 392.45841341705415 473.8787596734751 392.534842539868 473.9548602039482 L394.997128703304 476.4116905748902 L397.4649579132165 473.9548602039482 C397.54131212999675 473.87883424528354 397.6414864654195 473.84082748026856 397.74166080084217 473.84082748026856 C397.8418101675869 473.84082748026856 397.9419595343318 473.87883424528354 398.01833871978994 473.9548602039482 C398.17052281111626 474.1063652613494 398.17107212202825 474.35371994981534 398.01833871978994 474.50577186714474 L395.5499601989653 476.96314909801504 L398.0122713310791 479.4210731888136 C398.1644304537276 479.5725782462148 398.1650047333175 479.81993293468054 398.0116970514892 479.97143799208175 C397.93531786603114 480.0474639507466 397.8351684992863 480.0854707157615 397.7350191325414 480.0854707157615 C397.6348447971188 480.0854707157615 397.5346704616961 480.0474639507466 397.45831624491586 479.97143799208175 L394.9965793923919 477.51406076121157 L392.534842539868 479.9648259584036 C392.4585382604433 480.0407773452599 392.3583389563429 480.07865982392764 392.25821455827577 480.07865982392764 C392.15789041078637 480.07865982392764 392.05761620065226 480.0406406302779 391.9814617332947 479.9648259584036 C391.82872833105625 479.81277404107414 391.82872833105625 479.5659662125366 391.9814617332947 479.41391429520706 L394.44374789673066 476.9626022380868 L391.98088745370455 474.5052250072165 C391.82872833105625 474.3526262299588 391.82872833105625 474.10580597278647 391.9820110442067 473.95431334401997 C392.0580406681752 473.87862295849305 392.1579403481418 473.8407529084601 392.2579399028198 473.8407529084601 Z M395.0000250699313 468.0000900163443 C390.0505090339149 468.0000900163443 385.977917931692 472.0678703069019 386.000090117598 476.9999999999998 C385.9779928377253 481.91517703532134 390.022544114754 485.9778491570034 394.95975059260417 485.9998229832122 C394.97318374127246 485.99988512638583 394.986591921263 485.9999099836553 395.00000010125353 485.9999099836553 C399.94949116859215 485.9999099836553 404.02205730213734 481.93211726446305 403.999910084909 476.9999999999998 C404.02198239610385 472.0848229646783 399.97745608775307 468.02216327163103 395.0402496099029 468.00017701678746 C395.0268414299123 468.00011487361377 395.01343324992195 468.0000900163443 395.0000250699313 468.0000900163443 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_5-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_20" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_18" class="text firer focusin focusout pageunload commentable non-processed" customid="Dialog input"  datasizewidth="400.0px" datasizeheight="40.0px" dataX="15.0" dataY="507.2" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Last Name"/></div></div>  </div></div></div>\
        <div id="s-Subtraction_6" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="386.0" dataY="518.2"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="385.99995755694204 518.2378948943931 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_6-d1224" d="M392.2579399028198 524.0785577865089 C392.35813920692016 524.0785577865089 392.45841341705415 524.1165645515239 392.534842539868 524.192665081997 L394.997128703304 526.6494954529389 L397.4649579132165 524.192665081997 C397.54131212999675 524.1166391233323 397.6414864654195 524.0786323583173 397.74166080084217 524.0786323583173 C397.8418101675869 524.0786323583173 397.9419595343318 524.1166391233323 398.01833871978994 524.192665081997 C398.17052281111626 524.3441701393982 398.17107212202825 524.5915248278641 398.01833871978994 524.7435767451935 L395.5499601989653 527.2009539760638 L398.0122713310791 529.6588780668624 C398.1644304537276 529.8103831242636 398.1650047333175 530.0577378127293 398.0116970514892 530.2092428701305 C397.93531786603114 530.2852688287953 397.8351684992863 530.3232755938103 397.7350191325414 530.3232755938103 C397.6348447971188 530.3232755938103 397.5346704616961 530.2852688287953 397.45831624491586 530.2092428701305 L394.9965793923919 527.7518656392604 L392.534842539868 530.2026308364524 C392.4585382604433 530.2785822233087 392.3583389563429 530.3164647019764 392.25821455827577 530.3164647019764 C392.15789041078637 530.3164647019764 392.05761620065226 530.2784455083267 391.9814617332947 530.2026308364524 C391.82872833105625 530.0505789191229 391.82872833105625 529.8037710905853 391.9814617332947 529.6517191732559 L394.44374789673066 527.2004071161356 L391.98088745370455 524.7430298852653 C391.82872833105625 524.5904311080076 391.82872833105625 524.3436108508353 391.9820110442067 524.1921182220688 C392.0580406681752 524.1164278365418 392.1579403481418 524.0785577865089 392.2579399028198 524.0785577865089 Z M395.0000250699313 518.2378948943931 C390.0505090339149 518.2378948943931 385.977917931692 522.3056751849507 386.000090117598 527.2378048780486 C385.9779928377253 532.1529819133701 390.022544114754 536.2156540350522 394.95975059260417 536.237627861261 C394.97318374127246 536.2376900044346 394.986591921263 536.237714861704 395.00000010125353 536.237714861704 C399.94949116859215 536.237714861704 404.02205730213734 532.1699221425118 403.999910084909 527.2378048780486 C404.02198239610385 522.3226278427271 399.97745608775307 518.2599681496798 395.0402496099029 518.2379818948363 C395.0268414299123 518.2379197516625 395.01343324992195 518.2378948943931 395.0000250699313 518.2378948943931 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_6-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_1" class="image lockV firer pageload ie-background commentable non-processed" customid="Image 1"   datasizewidth="357.4px" datasizeheight="201.1px" dataX="36.3" dataY="217.4" aspectRatio="0.5625"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/4b8885b8-aa06-4076-9a2a-87ec317e8742.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="richtext autofit firer pageload ie-background commentable non-processed" customid="W-2 Form"   datasizewidth="246.6px" datasizeheight="55.0px" dataX="91.7" dataY="384.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">W-2 Form</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="145.0px" datasizeheight="50.0px" dataX="142.5" dataY="576.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">START</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;