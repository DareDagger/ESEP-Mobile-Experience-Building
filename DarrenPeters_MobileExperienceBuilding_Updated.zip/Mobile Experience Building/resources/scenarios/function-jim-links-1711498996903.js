(function(window, undefined) {

  var jimLinks = {
    "19bfb72a-4d98-4f80-96a1-9f3b485de48d" : {
      "Button_1" : [
        "f7a01636-d4e7-46dc-9dc1-7e344a1c4859"
      ],
      "Button_2" : [
        "9d38bba6-b3a8-43f9-be1e-06ce38eeba31"
      ]
    },
    "94dc381d-4432-4358-9d64-b2928ba6b371" : {
      "Button_1" : [
        "df6150cc-8d6d-4369-b499-c617f94b6277"
      ],
      "Button_2" : [
        "f7a01636-d4e7-46dc-9dc1-7e344a1c4859"
      ]
    },
    "df6150cc-8d6d-4369-b499-c617f94b6277" : {
      "Button_1" : [
        "be5aa2af-b364-4483-bce3-2c00b70b2e1c"
      ],
      "Button_2" : [
        "94dc381d-4432-4358-9d64-b2928ba6b371"
      ]
    },
    "b9f79ce8-5da9-4f98-acf8-087f714232a0" : {
    },
    "be5aa2af-b364-4483-bce3-2c00b70b2e1c" : {
      "Paragraph_2" : [
        "9d38bba6-b3a8-43f9-be1e-06ce38eeba31"
      ],
      "Paragraph_3" : [
        "19bfb72a-4d98-4f80-96a1-9f3b485de48d"
      ],
      "Paragraph_4" : [
        "f7a01636-d4e7-46dc-9dc1-7e344a1c4859"
      ],
      "Paragraph_5" : [
        "94dc381d-4432-4358-9d64-b2928ba6b371"
      ],
      "Button_1" : [
        "b9f79ce8-5da9-4f98-acf8-087f714232a0"
      ]
    },
    "f7a01636-d4e7-46dc-9dc1-7e344a1c4859" : {
      "Button_1" : [
        "94dc381d-4432-4358-9d64-b2928ba6b371"
      ],
      "Button_2" : [
        "19bfb72a-4d98-4f80-96a1-9f3b485de48d"
      ]
    },
    "9d38bba6-b3a8-43f9-be1e-06ce38eeba31" : {
      "Button_1" : [
        "19bfb72a-4d98-4f80-96a1-9f3b485de48d"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "9d38bba6-b3a8-43f9-be1e-06ce38eeba31"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);