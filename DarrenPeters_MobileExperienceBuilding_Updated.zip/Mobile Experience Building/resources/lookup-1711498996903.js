(function(window, undefined) {
  var dictionary = {
    "19bfb72a-4d98-4f80-96a1-9f3b485de48d": "Employee Information",
    "94dc381d-4432-4358-9d64-b2928ba6b371": "Additional Information",
    "df6150cc-8d6d-4369-b499-c617f94b6277": "Additional Information 2",
    "b9f79ce8-5da9-4f98-acf8-087f714232a0": "Thank You",
    "be5aa2af-b364-4483-bce3-2c00b70b2e1c": "Submit Screen",
    "f7a01636-d4e7-46dc-9dc1-7e344a1c4859": "Wages, Tips, & Tax Withheld",
    "9d38bba6-b3a8-43f9-be1e-06ce38eeba31": "Employer Information",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Start Screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);